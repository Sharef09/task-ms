-- Task Management System Backup
-- Generated: 2026-06-10 10:19:44

SET FOREIGN_KEY_CHECKS = 0;


DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `record_id` int(10) unsigned DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `device` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activity_logs_user_id` (`user_id`),
  KEY `idx_activity_logs_action` (`action`),
  KEY `idx_activity_logs_module` (`module`),
  KEY `idx_activity_logs_record_id` (`record_id`),
  CONSTRAINT `fk_activity_logs_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `old_value`, `new_value`, `ip_address`, `user_agent`, `device`, `created_at`, `updated_at`) VALUES
('1', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:23:47', '2026-06-09 12:23:47'),
('2', '1', 'Login', 'Auth', '1', NULL, NULL, '127.0.0.1', 'Mozilla/5.0', 'Desktop', '2026-06-09 11:31:36', '2026-06-09 12:31:36'),
('3', '1', 'Create', 'Tasks', '1', NULL, NULL, '127.0.0.1', 'Mozilla/5.0', 'Desktop', '2026-06-09 10:31:36', '2026-06-09 12:31:36'),
('4', '2', 'Update', 'Tasks', '1', NULL, NULL, '127.0.0.1', 'Mozilla/5.0', 'Desktop', '2026-06-09 12:01:36', '2026-06-09 12:31:36'),
('5', '1', 'Update Role', 'Roles', '2', NULL, '{\"name\":\"Manager\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:32:25', '2026-06-09 12:32:25'),
('6', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:33:26', '2026-06-09 12:33:26'),
('7', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:33:33', '2026-06-09 12:33:33'),
('8', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:37:42', '2026-06-09 12:37:42'),
('9', '1', 'Update General Settings', 'Settings', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:42:37', '2026-06-09 12:42:37'),
('10', '1', 'Update Profile', 'Profile', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:49:04', '2026-06-09 12:49:04'),
('11', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:49:51', '2026-06-09 12:49:51'),
('12', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:49:53', '2026-06-09 12:49:53'),
('13', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:52:47', '2026-06-09 12:52:47'),
('14', '1', 'Update Profile', 'Profile', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:53:04', '2026-06-09 12:53:04'),
('15', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:54:00', '2026-06-09 12:54:00'),
('16', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:54:02', '2026-06-09 12:54:02'),
('17', '1', 'Update Profile', 'Profile', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 11:59:55', '2026-06-09 12:59:55'),
('18', '1', 'Update Profile', 'Profile', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:00:03', '2026-06-09 13:00:03'),
('19', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:02:04', '2026-06-09 13:02:04'),
('20', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:02:06', '2026-06-09 13:02:06'),
('21', '1', 'Update Profile', 'Profile', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:02:15', '2026-06-09 13:02:15'),
('22', '1', 'Update Profile', 'Profile', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:03:37', '2026-06-09 13:03:37'),
('23', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:05:44', '2026-06-09 13:05:44'),
('24', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:05:45', '2026-06-09 13:05:45'),
('25', '1', 'Create User', 'Users', '5', NULL, '{\"employee_id\":\"EMP-0004\",\"first_name\":\"Abdinasir\",\"last_name\":\"Salad Omar\",\"email\":\"Binnaasir.mog@gmail.com\",\"username\":\"JBH00177\",\"mobile\":\"0619068203\",\"role_id\":4,\"department_id\":2,\"status\":\"Active\",\"created_at\":\"2026-06-09 12:08:38\",\"password\":\"$2y$10$iI78tjOForfmUEG3PVmDR..dGoF8a2NzaAknkozimqQeqJbjqigvu\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:08:38', '2026-06-09 13:08:38'),
('26', '1', 'Admin Reset Password', 'Users', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:11:01', '2026-06-09 13:11:01'),
('27', '1', 'Update User', 'Users', '5', NULL, '{\"first_name\":\"Abdinasir\",\"last_name\":\"Salad Omar\",\"email\":\"Binnaasir.mog@gmail.com\",\"mobile\":\"0619068203\",\"role_id\":4,\"department_id\":2,\"status\":\"Active\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:15:25', '2026-06-09 13:15:25'),
('28', '1', 'Update User', 'Users', '5', NULL, '{\"first_name\":\"Abdinasir\",\"last_name\":\"Salad Omar\",\"email\":\"Binnaasir.mog@gmail.com\",\"mobile\":\"0619068203\",\"role_id\":4,\"department_id\":2,\"status\":\"Active\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:16:59', '2026-06-09 13:16:59'),
('29', NULL, 'Account Lock', 'Auth', '5', NULL, '{\"reason\":\"Max failed attempts\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 12:19:57', '2026-06-09 13:19:57'),
('30', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:21:37', '2026-06-09 13:21:37'),
('31', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:21:38', '2026-06-09 13:21:38'),
('32', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 12:23:01', '2026-06-09 13:23:01'),
('33', '1', 'Update Notification Preferences', 'Profile', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 12:23:20', '2026-06-09 13:23:20'),
('34', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 12:25:42', '2026-06-09 13:25:42'),
('35', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 12:25:55', '2026-06-09 13:25:55'),
('36', '5', 'Update Notification Preferences', 'Profile', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 12:26:15', '2026-06-09 13:26:15'),
('37', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:31:01', '2026-06-09 13:31:01'),
('38', '1', 'Create Task', 'Tasks', '4', NULL, '{\"task_number\":\"TASK-00004\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 12:40:09', '2026-06-09 13:40:09'),
('39', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 14:02:01', '2026-06-09 15:02:01'),
('40', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 14:02:29', '2026-06-09 15:02:29'),
('41', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 14:08:50', '2026-06-09 15:08:50'),
('42', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 14:08:52', '2026-06-09 15:08:52'),
('43', '5', 'Add Comment', 'Tasks', '4', NULL, '{\"comment_id\":4,\"is_internal\":false}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 14:09:38', '2026-06-09 15:09:38'),
('44', '1', 'Add Comment', 'Tasks', '4', NULL, '{\"comment_id\":5,\"is_internal\":false}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 14:10:09', '2026-06-09 15:10:09'),
('45', '1', 'Add Comment', 'Tasks', '4', NULL, '{\"comment_id\":6,\"is_internal\":true}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 14:10:25', '2026-06-09 15:10:25'),
('46', '5', 'Archive Task', 'Tasks', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 14:15:37', '2026-06-09 15:15:37'),
('47', '1', 'Complete Task', 'Tasks', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 14:27:47', '2026-06-09 15:27:47'),
('48', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 14:36:23', '2026-06-09 15:36:23'),
('49', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 14:52:24', '2026-06-09 15:52:24'),
('50', '5', 'Delete Notification', 'Notifications', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 15:06:23', '2026-06-09 16:06:23'),
('51', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 15:06:32', '2026-06-09 16:06:32'),
('52', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', '', 'Desktop', '2026-06-09 15:11:27', '2026-06-09 16:11:27'),
('53', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', '', 'Desktop', '2026-06-09 15:12:19', '2026-06-09 16:12:19'),
('54', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', '', 'Desktop', '2026-06-09 15:14:05', '2026-06-09 16:14:05'),
('55', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', '', 'Desktop', '2026-06-09 15:15:01', '2026-06-09 16:15:01'),
('56', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', '', 'Desktop', '2026-06-09 15:15:22', '2026-06-09 16:15:22'),
('57', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 15:17:44', '2026-06-09 16:17:44'),
('58', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 15:17:45', '2026-06-09 16:17:45'),
('59', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 15:18:02', '2026-06-09 16:18:02'),
('60', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 15:18:16', '2026-06-09 16:18:16'),
('61', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', '', 'Desktop', '2026-06-09 15:20:02', '2026-06-09 16:20:02'),
('62', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', '', 'Desktop', '2026-06-09 15:20:12', '2026-06-09 16:20:12'),
('63', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', '', 'Desktop', '2026-06-09 15:20:28', '2026-06-09 16:20:28'),
('64', '1', 'Create Meeting', 'Meetings', '1', NULL, '{\"title\":\"Test Meeting from API\"}', '::1', '', 'Desktop', '2026-06-09 15:20:28', '2026-06-09 16:20:28'),
('65', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:27:09', '2026-06-09 16:27:09'),
('66', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:27:20', '2026-06-09 16:27:20'),
('67', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:27:27', '2026-06-09 16:27:27'),
('68', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:27:38', '2026-06-09 16:27:38'),
('69', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:27:55', '2026-06-09 16:27:55'),
('70', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:28:03', '2026-06-09 16:28:03'),
('71', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:28:08', '2026-06-09 16:28:08'),
('72', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:28:13', '2026-06-09 16:28:13'),
('73', '5', 'Upload File', 'User Files', NULL, NULL, '{\"name\":\"Enterprise_Task_Management_System_Prompt.pdf\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 15:29:42', '2026-06-09 16:29:42'),
('74', '5', 'Submit Idea', 'Employee Ideas', '1', NULL, '{\"title\":\"Systemka hala uprove gareyo\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 15:30:37', '2026-06-09 16:30:37'),
('75', '1', 'Review Idea', 'Employee Ideas', '1', 'Submitted', 'Under Review', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 15:31:34', '2026-06-09 16:31:34'),
('76', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:36:38', '2026-06-09 16:36:38'),
('77', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:41:52', '2026-06-09 16:41:52'),
('78', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:47:16', '2026-06-09 16:47:16'),
('79', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 15:48:05', '2026-06-09 16:48:05'),
('80', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:50:08', '2026-06-09 16:50:08'),
('81', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:55:52', '2026-06-09 16:55:52'),
('82', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:58:03', '2026-06-09 16:58:03'),
('83', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 15:58:08', '2026-06-09 16:58:08'),
('84', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 15:58:23', '2026-06-09 16:58:23'),
('85', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 15:58:24', '2026-06-09 16:58:24'),
('86', '1', 'Complete Task', 'Tasks', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 16:03:48', '2026-06-09 17:03:48'),
('87', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 16:05:33', '2026-06-09 17:05:33'),
('88', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 16:13:39', '2026-06-09 17:13:39'),
('89', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 16:22:41', '2026-06-09 17:22:41'),
('90', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-09 16:28:26', '2026-06-09 17:28:26'),
('91', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:32:09', '2026-06-09 17:32:09'),
('92', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:33:35', '2026-06-09 17:33:35'),
('93', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:35:53', '2026-06-09 17:35:53'),
('94', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:36:17', '2026-06-09 17:36:17'),
('95', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:39:03', '2026-06-09 17:39:03'),
('96', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:40:17', '2026-06-09 17:40:17'),
('97', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:40:26', '2026-06-09 17:40:26'),
('98', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:40:34', '2026-06-09 17:40:34'),
('99', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:41:01', '2026-06-09 17:41:01'),
('100', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:41:22', '2026-06-09 17:41:22'),
('101', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:41:30', '2026-06-09 17:41:30'),
('102', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:42:11', '2026-06-09 17:42:11'),
('103', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:43:23', '2026-06-09 17:43:23'),
('104', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:44:01', '2026-06-09 17:44:01'),
('105', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:44:18', '2026-06-09 17:44:18'),
('106', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', 'Desktop', '2026-06-09 16:44:24', '2026-06-09 17:44:24'),
('107', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-09 16:45:40', '2026-06-09 17:45:40'),
('108', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 08:08:13', '2026-06-10 09:08:13'),
('109', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:09:54', '2026-06-10 09:09:54'),
('110', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:42:29', '2026-06-10 09:42:29'),
('111', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:46:53', '2026-06-10 09:46:53'),
('112', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:46:55', '2026-06-10 09:46:55'),
('113', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:46:56', '2026-06-10 09:46:56'),
('114', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:46:58', '2026-06-10 09:46:58'),
('115', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:47:22', '2026-06-10 09:47:22'),
('116', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:47:34', '2026-06-10 09:47:34'),
('117', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:49:21', '2026-06-10 09:49:21'),
('118', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:49:28', '2026-06-10 09:49:28'),
('119', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:49:30', '2026-06-10 09:49:30'),
('120', '5', 'Change Password', 'Profile', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:54:03', '2026-06-10 09:54:03'),
('121', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:54:15', '2026-06-10 09:54:15'),
('122', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 08:54:17', '2026-06-10 09:54:17'),
('123', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 08:54:44', '2026-06-10 09:54:44'),
('124', '1', 'Create Task', 'Tasks', '5', NULL, '{\"task_number\":\"TASK-00005\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 08:56:24', '2026-06-10 09:56:24'),
('125', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:02:13', '2026-06-10 10:02:13'),
('126', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:02:14', '2026-06-10 10:02:14'),
('127', '1', 'Create Task', 'Tasks', '6', NULL, '{\"task_number\":\"TASK-00006\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 09:04:21', '2026-06-10 10:04:21'),
('128', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:10:51', '2026-06-10 10:10:51'),
('129', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:10:52', '2026-06-10 10:10:52'),
('130', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:11:09', '2026-06-10 10:11:09'),
('131', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:16:32', '2026-06-10 10:16:32'),
('132', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:16:34', '2026-06-10 10:16:34'),
('133', '1', 'Create Task', 'Tasks', '7', NULL, '{\"task_number\":\"TASK-00007\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 09:17:32', '2026-06-10 10:17:32'),
('134', '5', 'Start Task', 'Tasks', '7', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:18:09', '2026-06-10 10:18:09'),
('135', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 09:34:16', '2026-06-10 10:34:16'),
('136', '1', 'Create Task', 'Tasks', '8', NULL, '{\"task_number\":\"TASK-00008\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 09:34:59', '2026-06-10 10:34:59'),
('137', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:47:46', '2026-06-10 10:47:46'),
('138', '5', 'Logout', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:53:13', '2026-06-10 10:53:13'),
('139', '1', 'Delete Meeting', 'Meetings', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 09:53:53', '2026-06-10 10:53:53'),
('140', '5', 'Login', 'Auth', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'Desktop', '2026-06-10 09:54:01', '2026-06-10 10:54:01'),
('141', '1', 'Logout', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 10:01:29', '2026-06-10 11:01:29'),
('142', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 10:01:31', '2026-06-10 11:01:31'),
('143', '1', 'Login', 'Auth', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'Desktop', '2026-06-10 10:01:54', '2026-06-10 11:01:54');


DROP TABLE IF EXISTS `backup_history`;
CREATE TABLE `backup_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `type` enum('manual','scheduled') NOT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `status` enum('success','failed') DEFAULT 'success',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_backup_history_created_by` (`created_by`),
  CONSTRAINT `fk_backup_history_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_departments_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `departments` (`id`, `name`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1', 'Administration', 'Handles administrative and operational tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38', NULL),
('2', 'Development', 'Software development and engineering team', '2026-06-09 12:15:38', '2026-06-09 12:15:38', NULL),
('3', 'Design', 'UI/UX and graphic design team', '2026-06-09 12:15:38', '2026-06-09 12:15:38', NULL),
('4', 'Marketing', 'Marketing and brand management', '2026-06-09 12:15:38', '2026-06-09 12:15:38', NULL),
('5', 'Sales', 'Sales and business development', '2026-06-09 12:15:38', '2026-06-09 12:15:38', NULL),
('6', 'Human Resources', 'HR and personnel management', '2026-06-09 12:15:38', '2026-06-09 12:15:38', NULL),
('7', 'Finance', 'Financial management and accounting', '2026-06-09 12:15:38', '2026-06-09 12:15:38', NULL),
('15', 'Engineering', 'Software and systems engineering', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('16', 'Quality Assurance', 'Testing and quality control', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('17', 'Customer Support', 'Customer service and support', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL);


DROP TABLE IF EXISTS `email_logs`;
CREATE TABLE `email_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recipient` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `status` enum('sent','failed') NOT NULL,
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email_logs_recipient` (`recipient`),
  KEY `idx_email_logs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `template_type` varchar(50) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email_templates_template_type` (`template_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `email_templates` (`id`, `name`, `template_type`, `subject`, `body`, `status`, `created_at`, `updated_at`) VALUES
('1', 'Password Reset OTP', 'password_reset_otp', 'Your Password Reset OTP Code', '<!DOCTYPE html><html><body style=\"font-family: Arial, sans-serif; padding: 20px;\"><h2>Password Reset Request</h2><p>Dear {full_name},</p><p>You have requested to reset your password. Use the OTP code below to proceed:</p><div style=\"text-align: center; margin: 30px 0;\"><span style=\"font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #2563eb;\">{otp_code}</span></div><p>This OTP will expire in {otp_expiry_minutes} minutes.</p><p>If you did not request this, please ignore this email.</p><br><p>Best regards,<br>Task Management System</p></body></html>', 'active', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('2', 'Task Assignment Notification', 'task_assigned', 'New Task Assigned: {task_title}', '<!DOCTYPE html><html><body style=\"font-family: Arial, sans-serif; padding: 20px;\"><h2>Task Assignment</h2><p>Dear {assigned_to_name},</p><p>You have been assigned a new task by <strong>{assigned_by_name}</strong>.</p><table style=\"border-collapse: collapse; width: 100%; max-width: 500px; margin: 20px 0;\"><tr><td style=\"padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;\">Task:</td><td style=\"padding: 8px; border-bottom: 1px solid #ddd;\">{task_title}</td></tr><tr><td style=\"padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;\">Priority:</td><td style=\"padding: 8px; border-bottom: 1px solid #ddd;\">{priority}</td></tr><tr><td style=\"padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;\">Due Date:</td><td style=\"padding: 8px; border-bottom: 1px solid #ddd;\">{due_date}</td></tr><tr><td style=\"padding: 8px; font-weight: bold;\">Description:</td><td style=\"padding: 8px;\">{task_description}</td></tr></table><p>Please log in to the system to view details.</p><br><p>Best regards,<br>Task Management System</p></body></html>', 'active', '2026-06-09 12:15:38', '2026-06-09 12:15:38');


DROP TABLE IF EXISTS `employee_ideas`;
CREATE TABLE `employee_ideas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` enum('Improvement','Innovation','Efficiency','Cost Saving','Safety','Other') DEFAULT 'Improvement',
  `status` enum('Submitted','Under Review','Approved','Implemented','Rejected') DEFAULT 'Submitted',
  `submitted_by` int(10) unsigned NOT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `review_notes` text DEFAULT NULL,
  `estimated_savings` decimal(12,2) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ei_submitted_by` (`submitted_by`),
  KEY `idx_ei_status` (`status`),
  KEY `idx_ei_category` (`category`),
  KEY `fk_ei_reviewed_by` (`reviewed_by`),
  CONSTRAINT `fk_ei_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ei_submitted_by` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `employee_ideas` (`id`, `title`, `description`, `category`, `status`, `submitted_by`, `reviewed_by`, `review_notes`, `estimated_savings`, `attachment`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1', 'Systemka hala uprove gareyo', '', 'Improvement', 'Under Review', '5', '1', 'waala review garena', NULL, NULL, '2026-06-09 15:30:37', '2026-06-09 16:31:34', NULL);


DROP TABLE IF EXISTS `login_logs`;
CREATE TABLE `login_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `status` enum('success','failed') NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_login_logs_user_id` (`user_id`),
  KEY `idx_login_logs_status` (`status`),
  CONSTRAINT `fk_login_logs_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `login_logs` (`id`, `user_id`, `username`, `status`, `ip_address`, `user_agent`, `created_at`, `updated_at`) VALUES
('1', '1', 'admin@taskms.com', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:19:19', '2026-06-09 12:19:19'),
('2', '1', 'admin@taskms.com', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:20:38', '2026-06-09 12:20:38'),
('3', NULL, 'amdin', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:20:59', '2026-06-09 12:20:59'),
('4', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:23:47', '2026-06-09 12:23:47'),
('5', '1', 'admin', 'success', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '2026-06-09 11:31:36', '2026-06-09 12:31:36'),
('6', '2', 'john', 'success', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', '2026-06-09 10:31:36', '2026-06-09 12:31:36'),
('7', '3', 'jane', 'success', '192.168.1.100', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', '2026-06-09 09:31:36', '2026-06-09 12:31:36'),
('8', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:33:33', '2026-06-09 12:33:33'),
('9', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:37:42', '2026-06-09 12:37:42'),
('10', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:49:53', '2026-06-09 12:49:53'),
('11', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:52:47', '2026-06-09 12:52:47'),
('12', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 11:54:02', '2026-06-09 12:54:02'),
('13', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 12:02:06', '2026-06-09 13:02:06'),
('14', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 12:05:45', '2026-06-09 13:05:45'),
('15', '5', 'JBH00177', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:16:12', '2026-06-09 13:16:12'),
('16', '5', 'JBH00177', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:16:32', '2026-06-09 13:16:32'),
('17', '5', 'JBH00177', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:17:16', '2026-06-09 13:17:16'),
('18', '5', 'JBH00177', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:19:18', '2026-06-09 13:19:18'),
('19', '5', 'JBH00177', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:19:57', '2026-06-09 13:19:57'),
('20', '5', 'JBH00177', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:19:57', '2026-06-09 13:19:57'),
('21', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 12:21:38', '2026-06-09 13:21:38'),
('22', NULL, 'admin@taskms.com', 'failed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:22:11', '2026-06-09 13:22:11'),
('23', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:23:01', '2026-06-09 13:23:01'),
('24', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 12:25:55', '2026-06-09 13:25:55'),
('25', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 12:31:01', '2026-06-09 13:31:01'),
('26', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 14:02:01', '2026-06-09 15:02:01'),
('27', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 14:02:29', '2026-06-09 15:02:29'),
('28', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 14:08:52', '2026-06-09 15:08:52'),
('29', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 14:36:23', '2026-06-09 15:36:23'),
('30', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 14:52:24', '2026-06-09 15:52:24'),
('31', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 15:06:32', '2026-06-09 16:06:32'),
('32', '1', 'admin', 'success', '::1', '', '2026-06-09 15:11:27', '2026-06-09 16:11:27'),
('33', '1', 'admin', 'success', '::1', '', '2026-06-09 15:12:19', '2026-06-09 16:12:19'),
('34', '1', 'admin', 'success', '::1', '', '2026-06-09 15:14:05', '2026-06-09 16:14:05'),
('35', '1', 'admin', 'success', '::1', '', '2026-06-09 15:15:01', '2026-06-09 16:15:01'),
('36', '1', 'admin', 'success', '::1', '', '2026-06-09 15:15:22', '2026-06-09 16:15:22'),
('37', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 15:17:45', '2026-06-09 16:17:45'),
('38', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 15:18:16', '2026-06-09 16:18:16'),
('39', '1', 'admin', 'success', '::1', '', '2026-06-09 15:20:02', '2026-06-09 16:20:02'),
('40', '1', 'admin', 'success', '::1', '', '2026-06-09 15:20:12', '2026-06-09 16:20:12'),
('41', '1', 'admin', 'success', '::1', '', '2026-06-09 15:20:28', '2026-06-09 16:20:28'),
('42', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:27:09', '2026-06-09 16:27:09'),
('43', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:27:20', '2026-06-09 16:27:20'),
('44', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:27:27', '2026-06-09 16:27:27'),
('45', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:27:38', '2026-06-09 16:27:38'),
('46', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:27:55', '2026-06-09 16:27:55'),
('47', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:28:03', '2026-06-09 16:28:03'),
('48', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:28:08', '2026-06-09 16:28:08'),
('49', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:28:13', '2026-06-09 16:28:13'),
('50', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:36:38', '2026-06-09 16:36:38'),
('51', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:41:52', '2026-06-09 16:41:52'),
('52', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:47:16', '2026-06-09 16:47:16'),
('53', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 15:48:05', '2026-06-09 16:48:05'),
('54', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:50:08', '2026-06-09 16:50:08'),
('55', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:55:52', '2026-06-09 16:55:52'),
('56', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:58:03', '2026-06-09 16:58:03'),
('57', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 15:58:08', '2026-06-09 16:58:08'),
('58', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 15:58:24', '2026-06-09 16:58:24'),
('59', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 16:05:33', '2026-06-09 17:05:33'),
('60', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-09 16:28:26', '2026-06-09 17:28:26'),
('61', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:32:09', '2026-06-09 17:32:09'),
('62', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:33:35', '2026-06-09 17:33:35'),
('63', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:35:53', '2026-06-09 17:35:53'),
('64', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:36:17', '2026-06-09 17:36:17'),
('65', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:39:03', '2026-06-09 17:39:03'),
('66', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:40:17', '2026-06-09 17:40:17'),
('67', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:40:26', '2026-06-09 17:40:26'),
('68', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:40:34', '2026-06-09 17:40:34'),
('69', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:41:01', '2026-06-09 17:41:01'),
('70', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:41:22', '2026-06-09 17:41:22'),
('71', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:41:30', '2026-06-09 17:41:30'),
('72', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:42:11', '2026-06-09 17:42:11'),
('73', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:43:23', '2026-06-09 17:43:23'),
('74', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:44:01', '2026-06-09 17:44:01'),
('75', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:44:18', '2026-06-09 17:44:18'),
('76', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920', '2026-06-09 16:44:24', '2026-06-09 17:44:24'),
('77', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-09 16:45:40', '2026-06-09 17:45:40'),
('78', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-10 08:08:13', '2026-06-10 09:08:13'),
('79', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 08:09:54', '2026-06-10 09:09:54'),
('80', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 08:42:29', '2026-06-10 09:42:29'),
('81', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 08:46:55', '2026-06-10 09:46:55'),
('82', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 08:46:58', '2026-06-10 09:46:58'),
('83', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 08:47:22', '2026-06-10 09:47:22'),
('84', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 08:49:21', '2026-06-10 09:49:21'),
('85', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 08:49:30', '2026-06-10 09:49:30'),
('86', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 08:54:17', '2026-06-10 09:54:17'),
('87', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-10 08:54:44', '2026-06-10 09:54:44'),
('88', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 09:02:14', '2026-06-10 10:02:14'),
('89', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 09:10:52', '2026-06-10 10:10:52'),
('90', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 09:11:09', '2026-06-10 10:11:09'),
('91', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 09:16:34', '2026-06-10 10:16:34'),
('92', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-10 09:34:16', '2026-06-10 10:34:16'),
('93', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 09:47:46', '2026-06-10 10:47:46'),
('94', '5', 'JBH00177', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-06-10 09:54:01', '2026-06-10 10:54:01'),
('95', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-10 10:01:31', '2026-06-10 11:01:31'),
('96', '1', 'admin', 'success', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-10 10:01:54', '2026-06-10 11:01:54');


DROP TABLE IF EXISTS `meeting_sessions`;
CREATE TABLE `meeting_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meeting_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `presenter_id` int(10) unsigned DEFAULT NULL,
  `duration_minutes` int(10) unsigned DEFAULT NULL,
  `sort_order` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_meeting_sessions_meeting_id` (`meeting_id`),
  KEY `idx_meeting_sessions_presenter_id` (`presenter_id`),
  CONSTRAINT `k_ms_meeting_id` FOREIGN KEY (`meeting_id`) REFERENCES `meetings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `k_ms_presenter_id` FOREIGN KEY (`presenter_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `meeting_tasks`;
CREATE TABLE `meeting_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meeting_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('Pending','In Progress','Completed') DEFAULT 'Pending',
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_meeting_tasks_meeting_id` (`meeting_id`),
  KEY `idx_meeting_tasks_task_id` (`task_id`),
  KEY `idx_meeting_tasks_assigned_to` (`assigned_to`),
  CONSTRAINT `fk_mt_assigned_to` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_mt_meeting_id` FOREIGN KEY (`meeting_id`) REFERENCES `meetings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mt_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `meetings`;
CREATE TABLE `meetings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `organizer_id` int(10) unsigned NOT NULL,
  `status` enum('Scheduled','Ongoing','Completed','Cancelled') DEFAULT 'Scheduled',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_meetings_department_id` (`department_id`),
  KEY `idx_meetings_organizer_id` (`organizer_id`),
  KEY `idx_meetings_status` (`status`),
  CONSTRAINT `k_meetings_department_id` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `k_meetings_organizer_id` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `meetings` (`id`, `title`, `description`, `department_id`, `organizer_id`, `status`, `start_date`, `end_date`, `location`, `notes`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1', 'Test Meeting from API', 'This is a test', NULL, '1', 'Scheduled', '2026-06-10 10:00:00', '2026-06-10 11:00:00', 'Room 101', '', '2026-06-09 15:20:28', '2026-06-10 10:53:53', '2026-06-10 09:53:53');


DROP TABLE IF EXISTS `notification_preferences`;
CREATE TABLE `notification_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `email` tinyint(1) DEFAULT 1,
  `in_app` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notification_preferences_user_id` (`user_id`),
  CONSTRAINT `fk_notification_preferences_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `notification_preferences` (`id`, `user_id`, `type`, `email`, `in_app`, `created_at`, `updated_at`) VALUES
('1', '1', 'task_assigned', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('2', '2', 'task_assigned', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('3', '3', 'task_assigned', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('4', '4', 'task_assigned', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('8', '1', 'task_completed', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('9', '2', 'task_completed', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('10', '3', 'task_completed', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('11', '4', 'task_completed', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('15', '1', 'task_overdue', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('16', '2', 'task_overdue', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('17', '3', 'task_overdue', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('18', '4', 'task_overdue', '1', '1', '2026-06-09 12:31:36', '2026-06-09 12:31:36');


DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user_id` (`user_id`),
  KEY `idx_notifications_is_read` (`is_read`),
  CONSTRAINT `fk_notifications_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `message`, `link`, `is_read`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1', '2', 'task_assigned', 'New Task Assigned', 'You have been assigned TASK-00001: User Dashboard Redesign', '/tasks/view/1', '0', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('2', '3', 'task_assigned', 'New Task Assigned', 'You have been assigned TASK-00002: API Integration Module', '/tasks/view/2', '0', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('3', '1', 'task_completed', 'Task Completed', 'TASK-00003: Database Optimization has been completed', '/tasks/view/3', '0', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('5', '1', 'task_completed', 'Task Completed', 'Task TASK-00004: Test has been completed by Osman Sharif Ali', '/tasks/view/4', '1', '2026-06-09 16:03:48', '2026-06-10 11:10:00', NULL),
('6', '5', 'task_assigned', 'New Task Assigned', 'You have been assigned task TASK-00005: Test2 by Osman Sharif Ali', '/tasks/view/5', '0', '2026-06-10 08:56:24', '2026-06-10 09:56:24', NULL),
('7', '5', 'task_assigned', 'New Task Assigned', 'You have been assigned task TASK-00006: Test3 by Osman Sharif Ali', '/tasks/view/6', '0', '2026-06-10 09:04:21', '2026-06-10 10:04:21', NULL),
('8', '5', 'task_assigned', 'New Task Assigned', 'You have been assigned task TASK-00007: test by Osman Sharif Ali', '/tasks/view/7', '1', '2026-06-10 09:17:32', '2026-06-10 10:35:21', NULL),
('9', '5', 'task_assigned', 'New Task Assigned', 'You have been assigned task TASK-00008: head by Osman Sharif Ali', '/tasks/view/8', '1', '2026-06-10 09:34:59', '2026-06-10 10:35:13', NULL);


DROP TABLE IF EXISTS `otp_codes`;
CREATE TABLE `otp_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `email` varchar(100) NOT NULL,
  `otp` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `attempts` tinyint(4) DEFAULT 0,
  `used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_otp_codes_user_id` (`user_id`),
  KEY `idx_otp_codes_email` (`email`),
  CONSTRAINT `fk_otp_codes_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_password_resets_user_id` (`user_id`),
  KEY `idx_password_resets_token` (`token`(191)),
  CONSTRAINT `fk_password_resets_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `module` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permissions_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`id`, `name`, `slug`, `module`, `created_at`, `updated_at`) VALUES
('1', 'View Users', 'users.view', 'users', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('2', 'Add Users', 'users.add', 'users', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('3', 'Edit Users', 'users.edit', 'users', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('4', 'Delete Users', 'users.delete', 'users', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('5', 'Assign Users', 'users.assign', 'users', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('6', 'Approve Users', 'users.approve', 'users', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('7', 'Export Users', 'users.export', 'users', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('8', 'Print Users', 'users.print', 'users', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('9', 'View Roles', 'roles.view', 'roles', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('10', 'Add Roles', 'roles.add', 'roles', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('11', 'Edit Roles', 'roles.edit', 'roles', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('12', 'Delete Roles', 'roles.delete', 'roles', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('13', 'Assign Roles', 'roles.assign', 'roles', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('14', 'Approve Roles', 'roles.approve', 'roles', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('15', 'Export Roles', 'roles.export', 'roles', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('16', 'Print Roles', 'roles.print', 'roles', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('17', 'View Permissions', 'permissions.view', 'permissions', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('18', 'Add Permissions', 'permissions.add', 'permissions', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('19', 'Edit Permissions', 'permissions.edit', 'permissions', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('20', 'Delete Permissions', 'permissions.delete', 'permissions', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('21', 'Assign Permissions', 'permissions.assign', 'permissions', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('22', 'Approve Permissions', 'permissions.approve', 'permissions', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('23', 'Export Permissions', 'permissions.export', 'permissions', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('24', 'Print Permissions', 'permissions.print', 'permissions', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('25', 'View Tasks', 'tasks.view', 'tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('26', 'Add Tasks', 'tasks.add', 'tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('27', 'Edit Tasks', 'tasks.edit', 'tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('28', 'Delete Tasks', 'tasks.delete', 'tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('29', 'Assign Tasks', 'tasks.assign', 'tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('30', 'Approve Tasks', 'tasks.approve', 'tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('31', 'Export Tasks', 'tasks.export', 'tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('32', 'Print Tasks', 'tasks.print', 'tasks', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('33', 'View Categories', 'categories.view', 'categories', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('34', 'Add Categories', 'categories.add', 'categories', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('35', 'Edit Categories', 'categories.edit', 'categories', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('36', 'Delete Categories', 'categories.delete', 'categories', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('37', 'Assign Categories', 'categories.assign', 'categories', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('38', 'Approve Categories', 'categories.approve', 'categories', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('39', 'Export Categories', 'categories.export', 'categories', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('40', 'Print Categories', 'categories.print', 'categories', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('41', 'View Departments', 'departments.view', 'departments', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('42', 'Add Departments', 'departments.add', 'departments', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('43', 'Edit Departments', 'departments.edit', 'departments', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('44', 'Delete Departments', 'departments.delete', 'departments', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('45', 'Assign Departments', 'departments.assign', 'departments', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('46', 'Approve Departments', 'departments.approve', 'departments', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('47', 'Export Departments', 'departments.export', 'departments', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('48', 'Print Departments', 'departments.print', 'departments', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('49', 'View Reports', 'reports.view', 'reports', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('50', 'Add Reports', 'reports.add', 'reports', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('51', 'Edit Reports', 'reports.edit', 'reports', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('52', 'Delete Reports', 'reports.delete', 'reports', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('53', 'Assign Reports', 'reports.assign', 'reports', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('54', 'Approve Reports', 'reports.approve', 'reports', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('55', 'Export Reports', 'reports.export', 'reports', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('56', 'Print Reports', 'reports.print', 'reports', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('57', 'View Activity Logs', 'activity_logs.view', 'activity_logs', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('58', 'Add Activity Logs', 'activity_logs.add', 'activity_logs', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('59', 'Edit Activity Logs', 'activity_logs.edit', 'activity_logs', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('60', 'Delete Activity Logs', 'activity_logs.delete', 'activity_logs', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('61', 'Assign Activity Logs', 'activity_logs.assign', 'activity_logs', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('62', 'Approve Activity Logs', 'activity_logs.approve', 'activity_logs', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('63', 'Export Activity Logs', 'activity_logs.export', 'activity_logs', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('64', 'Print Activity Logs', 'activity_logs.print', 'activity_logs', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('65', 'View Notifications', 'notifications.view', 'notifications', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('66', 'Add Notifications', 'notifications.add', 'notifications', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('67', 'Edit Notifications', 'notifications.edit', 'notifications', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('68', 'Delete Notifications', 'notifications.delete', 'notifications', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('69', 'Assign Notifications', 'notifications.assign', 'notifications', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('70', 'Approve Notifications', 'notifications.approve', 'notifications', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('71', 'Export Notifications', 'notifications.export', 'notifications', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('72', 'Print Notifications', 'notifications.print', 'notifications', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('73', 'View Backup', 'backup.view', 'backup', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('74', 'Add Backup', 'backup.add', 'backup', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('75', 'Edit Backup', 'backup.edit', 'backup', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('76', 'Delete Backup', 'backup.delete', 'backup', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('77', 'Assign Backup', 'backup.assign', 'backup', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('78', 'Approve Backup', 'backup.approve', 'backup', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('79', 'Export Backup', 'backup.export', 'backup', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('80', 'Print Backup', 'backup.print', 'backup', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('81', 'View Settings', 'settings.view', 'settings', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('82', 'Add Settings', 'settings.add', 'settings', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('83', 'Edit Settings', 'settings.edit', 'settings', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('84', 'Delete Settings', 'settings.delete', 'settings', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('85', 'Assign Settings', 'settings.assign', 'settings', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('86', 'Approve Settings', 'settings.approve', 'settings', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('87', 'Export Settings', 'settings.export', 'settings', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('88', 'Print Settings', 'settings.print', 'settings', '2026-06-09 12:15:38', '2026-06-09 12:15:38');


DROP TABLE IF EXISTS `remember_tokens`;
CREATE TABLE `remember_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_remember_tokens_user_id` (`user_id`),
  KEY `idx_remember_tokens_token_hash` (`token_hash`(191)),
  CONSTRAINT `fk_remember_tokens_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `remember_tokens` (`id`, `user_id`, `token_hash`, `expires_at`, `created_at`, `updated_at`) VALUES
('1', '1', '8e1f940c67d088ce91ae9cf3aeb497d0fb5dc0e6d024db18cb3647c4c22ea353', '2026-07-09 11:33:33', '2026-06-09 11:33:33', '2026-06-09 12:33:33');


DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `idx_role_permissions_permission_id` (`permission_id`),
  CONSTRAINT `fk_role_permissions_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_role_permissions_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `created_at`) VALUES
('1', '1', '2026-06-09 12:15:38'),
('1', '2', '2026-06-09 12:15:38'),
('1', '3', '2026-06-09 12:15:38'),
('1', '4', '2026-06-09 12:15:38'),
('1', '5', '2026-06-09 12:15:38'),
('1', '6', '2026-06-09 12:15:38'),
('1', '7', '2026-06-09 12:15:38'),
('1', '8', '2026-06-09 12:15:38'),
('1', '9', '2026-06-09 12:15:38'),
('1', '10', '2026-06-09 12:15:38'),
('1', '11', '2026-06-09 12:15:38'),
('1', '12', '2026-06-09 12:15:38'),
('1', '13', '2026-06-09 12:15:38'),
('1', '14', '2026-06-09 12:15:38'),
('1', '15', '2026-06-09 12:15:38'),
('1', '16', '2026-06-09 12:15:38'),
('1', '17', '2026-06-09 12:15:38'),
('1', '18', '2026-06-09 12:15:38'),
('1', '19', '2026-06-09 12:15:38'),
('1', '20', '2026-06-09 12:15:38'),
('1', '21', '2026-06-09 12:15:38'),
('1', '22', '2026-06-09 12:15:38'),
('1', '23', '2026-06-09 12:15:38'),
('1', '24', '2026-06-09 12:15:38'),
('1', '25', '2026-06-09 12:15:38'),
('1', '26', '2026-06-09 12:15:38'),
('1', '27', '2026-06-09 12:15:38'),
('1', '28', '2026-06-09 12:15:38'),
('1', '29', '2026-06-09 12:15:38'),
('1', '30', '2026-06-09 12:15:38'),
('1', '31', '2026-06-09 12:15:38'),
('1', '32', '2026-06-09 12:15:38'),
('1', '33', '2026-06-09 12:15:38'),
('1', '34', '2026-06-09 12:15:38'),
('1', '35', '2026-06-09 12:15:38'),
('1', '36', '2026-06-09 12:15:38'),
('1', '37', '2026-06-09 12:15:38'),
('1', '38', '2026-06-09 12:15:38'),
('1', '39', '2026-06-09 12:15:38'),
('1', '40', '2026-06-09 12:15:38'),
('1', '41', '2026-06-09 12:15:38'),
('1', '42', '2026-06-09 12:15:38'),
('1', '43', '2026-06-09 12:15:38'),
('1', '44', '2026-06-09 12:15:38'),
('1', '45', '2026-06-09 12:15:38'),
('1', '46', '2026-06-09 12:15:38'),
('1', '47', '2026-06-09 12:15:38'),
('1', '48', '2026-06-09 12:15:38'),
('1', '49', '2026-06-09 12:15:38'),
('1', '50', '2026-06-09 12:15:38'),
('1', '51', '2026-06-09 12:15:38'),
('1', '52', '2026-06-09 12:15:38'),
('1', '53', '2026-06-09 12:15:38'),
('1', '54', '2026-06-09 12:15:38'),
('1', '55', '2026-06-09 12:15:38'),
('1', '56', '2026-06-09 12:15:38'),
('1', '57', '2026-06-09 12:15:38'),
('1', '58', '2026-06-09 12:15:38'),
('1', '59', '2026-06-09 12:15:38'),
('1', '60', '2026-06-09 12:15:38'),
('1', '61', '2026-06-09 12:15:38'),
('1', '62', '2026-06-09 12:15:38'),
('1', '63', '2026-06-09 12:15:38'),
('1', '64', '2026-06-09 12:15:38'),
('1', '65', '2026-06-09 12:15:38'),
('1', '66', '2026-06-09 12:15:38'),
('1', '67', '2026-06-09 12:15:38'),
('1', '68', '2026-06-09 12:15:38'),
('1', '69', '2026-06-09 12:15:38'),
('1', '70', '2026-06-09 12:15:38'),
('1', '71', '2026-06-09 12:15:38'),
('1', '72', '2026-06-09 12:15:38'),
('1', '73', '2026-06-09 12:15:38'),
('1', '74', '2026-06-09 12:15:38'),
('1', '75', '2026-06-09 12:15:38'),
('1', '76', '2026-06-09 12:15:38'),
('1', '77', '2026-06-09 12:15:38'),
('1', '78', '2026-06-09 12:15:38'),
('1', '79', '2026-06-09 12:15:38'),
('1', '80', '2026-06-09 12:15:38'),
('1', '81', '2026-06-09 12:15:38'),
('1', '82', '2026-06-09 12:15:38'),
('1', '83', '2026-06-09 12:15:38'),
('1', '84', '2026-06-09 12:15:38'),
('1', '85', '2026-06-09 12:15:38'),
('1', '86', '2026-06-09 12:15:38'),
('1', '87', '2026-06-09 12:15:38'),
('1', '88', '2026-06-09 12:15:38');


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_roles_name` (`name`),
  UNIQUE KEY `uk_roles_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES
('1', 'Administrator', 'administrator', 'Full system access and control', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('2', 'Manager', 'manager', 'Department management and oversight', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('3', 'Supervisor', 'supervisor', 'Team supervision and task management', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('4', 'Staff', 'staff', 'Regular staff member', '2026-06-09 12:15:38', '2026-06-09 12:15:38');


DROP TABLE IF EXISTS `special_meetings`;
CREATE TABLE `special_meetings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `requester_id` int(10) unsigned NOT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `preferred_date` datetime DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `meeting_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_special_meetings_requester_id` (`requester_id`),
  KEY `idx_special_meetings_approved_by` (`approved_by`),
  KEY `idx_special_meetings_status` (`status`),
  KEY `fk_sm_meeting_id` (`meeting_id`),
  CONSTRAINT `fk_sm_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_sm_meeting_id` FOREIGN KEY (`meeting_id`) REFERENCES `meetings` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_sm_requester_id` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_system_settings_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES
('1', 'session_timeout', '1800', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('2', 'otp_expiry', '600', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('3', 'password_expiry', '7776000', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('4', 'max_login_attempts', '5', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('5', 'lockout_duration', '1800', '2026-06-09 12:15:38', '2026-06-09 12:15:38'),
('6', 'site_name', 'Task Management System', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('7', 'company_name', 'Enterprise Inc.', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('8', 'timezone', 'UTC', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('9', 'language', 'en', '2026-06-09 12:31:36', '2026-06-09 12:31:36');


DROP TABLE IF EXISTS `task_assignments`;
CREATE TABLE `task_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `assigned_by` int(10) unsigned DEFAULT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_primary` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_user` (`task_id`,`user_id`),
  KEY `idx_ta_task_id` (`task_id`),
  KEY `idx_ta_user_id` (`user_id`),
  CONSTRAINT `fk_ta_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ta_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `task_attachments`;
CREATE TABLE `task_attachments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `stored_name` varchar(255) NOT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `extension` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task_attachments_task_id` (`task_id`),
  KEY `idx_task_attachments_user_id` (`user_id`),
  CONSTRAINT `fk_task_attachments_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_task_attachments_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `task_attachments` (`id`, `task_id`, `user_id`, `original_name`, `stored_name`, `mime_type`, `file_size`, `file_path`, `extension`, `created_at`, `updated_at`) VALUES
('1', '1', '2', 'mockup-v1.png', 'mockup-02f1ee33-63e6-11f1-85fd-5c60bab89887', 'image/png', '204800', NULL, NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('2', '2', '3', 'api-specs.pdf', 'api-specs-02f27a4b-63e6-11f1-85fd-5c60bab89887', 'application/pdf', '512000', NULL, NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('3', '3', '4', 'query-report.xlsx', 'query-report-02f3ea71-63e6-11f1-85fd-5c60bab89887', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '1024000', NULL, NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('4', '7', '1', 'Inventroy.png', 'file_6a290f8c1b2555.93477403.png', 'image/png', '20359', 'public/storage/uploads/tasks/7/file_6a290f8c1b2555.93477403.png', 'png', '2026-06-10 09:17:32', '2026-06-10 10:17:32'),
('5', '8', '1', 'Active and Inactive Items Report.xlsx', 'file_6a2913a33b66e4.22634731.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '266797', 'public/storage/uploads/tasks/8/file_6a2913a33b66e4.22634731.xlsx', 'xlsx', '2026-06-10 09:34:59', '2026-06-10 10:34:59');


DROP TABLE IF EXISTS `task_categories`;
CREATE TABLE `task_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(7) DEFAULT '#2563eb',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `task_categories` (`id`, `name`, `description`, `color`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1', 'Development', 'Software development tasks', '#2563eb', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('2', 'Design', 'UI/UX design tasks', '#d97706', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('3', 'Testing', 'Testing and QA tasks', '#16a34a', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL);


DROP TABLE IF EXISTS `task_comments`;
CREATE TABLE `task_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `comment` text NOT NULL,
  `is_internal` tinyint(1) DEFAULT 0,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task_comments_task_id` (`task_id`),
  KEY `idx_task_comments_user_id` (`user_id`),
  CONSTRAINT `fk_task_comments_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_task_comments_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `task_comments` (`id`, `task_id`, `user_id`, `comment`, `is_internal`, `attachment`, `created_at`, `updated_at`) VALUES
('1', '1', '2', 'Started working on the wireframes. Will share the mockups soon.', '0', NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('2', '1', '1', 'Please focus on mobile-first approach.', '1', NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('3', '2', '3', 'API documentation is ready for review.', '0', NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('4', '4', '5', 'away file kii', '0', NULL, '2026-06-09 14:09:38', '2026-06-09 15:09:38'),
('5', '4', '1', 'wuu ku attech gareysanyhay', '0', NULL, '2026-06-09 14:10:09', '2026-06-09 15:10:09'),
('6', '4', '1', 'waakan', '1', 'storage/uploads/comments/4/comment_6a2802b149b1c.pdf', '2026-06-09 14:10:25', '2026-06-09 15:10:25');


DROP TABLE IF EXISTS `task_dependencies`;
CREATE TABLE `task_dependencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `depends_on_id` int(10) unsigned NOT NULL,
  `dependency_type` enum('blocks','blocked_by','related') DEFAULT 'blocked_by',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_dep` (`task_id`,`depends_on_id`),
  KEY `idx_td_task_id` (`task_id`),
  KEY `idx_td_depends_on_id` (`depends_on_id`),
  CONSTRAINT `fk_td_depends_on_id` FOREIGN KEY (`depends_on_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_td_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `task_history`;
CREATE TABLE `task_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `field_changed` varchar(50) NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task_history_task_id` (`task_id`),
  KEY `idx_task_history_user_id` (`user_id`),
  CONSTRAINT `fk_task_history_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_task_history_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `task_history` (`id`, `task_id`, `user_id`, `field_changed`, `old_value`, `new_value`, `created_at`, `updated_at`) VALUES
('1', '1', '1', 'status', 'Draft', 'Assigned', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('2', '1', '2', 'status', 'Assigned', 'In Progress', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('3', '3', '4', 'status', 'Assigned', 'Completed', '2026-06-09 12:31:36', '2026-06-09 12:31:36'),
('4', '4', '1', 'created', NULL, '{\"task_number\":\"TASK-00004\",\"title\":\"Test\",\"description\":\"dddd\",\"priority\":\"Medium\",\"status\":\"Draft\",\"department_id\":3,\"category_id\":2,\"assigned_to\":5,\"estimated_hours\":1,\"due_date\":\"2026-06-10\",\"created_by\":1,\"created_at\":\"2026-06-09 12:40:09\",\"assigned_by\":1,\"assigned_at\":\"2026-06-09 12:40:09\"}', '2026-06-09 12:40:09', '2026-06-09 13:40:09'),
('5', '4', '5', 'archived', '0', '1', '2026-06-09 14:15:37', '2026-06-09 15:15:37'),
('6', '1', '1', 'status', 'In Progress', 'Completed', '2026-06-09 14:27:47', '2026-06-09 15:27:47'),
('7', '4', '1', 'status', 'Draft', 'Completed', '2026-06-09 16:03:48', '2026-06-09 17:03:48'),
('8', '5', '1', 'created', NULL, '{\"task_number\":\"TASK-00005\",\"title\":\"Test2\",\"task_type\":\"File Attached\",\"description\":\"fast\",\"priority\":\"High\",\"status\":\"Draft\",\"department_id\":3,\"category_id\":2,\"assigned_to\":5,\"estimated_hours\":5,\"due_date\":\"2026-06-11\",\"created_by\":1,\"created_at\":\"2026-06-10 08:56:24\",\"assigned_by\":1,\"assigned_at\":\"2026-06-10 08:56:24\"}', '2026-06-10 08:56:24', '2026-06-10 09:56:24'),
('9', '6', '1', 'created', NULL, '{\"task_number\":\"TASK-00006\",\"title\":\"Test3\",\"task_type\":\"File Attached\",\"description\":\"sure\",\"priority\":\"Low\",\"status\":\"Draft\",\"department_id\":3,\"category_id\":2,\"assigned_to\":5,\"estimated_hours\":1,\"due_date\":\"2026-06-11\",\"created_by\":1,\"created_at\":\"2026-06-10 09:04:21\",\"assigned_by\":1,\"assigned_at\":\"2026-06-10 09:04:21\"}', '2026-06-10 09:04:21', '2026-06-10 10:04:21'),
('10', '7', '1', 'created', NULL, '{\"task_number\":\"TASK-00007\",\"title\":\"test\",\"task_type\":\"Normal\",\"description\":\"tttt\",\"priority\":\"Low\",\"status\":\"Draft\",\"department_id\":3,\"category_id\":2,\"assigned_to\":5,\"estimated_hours\":1,\"due_date\":\"2026-06-11\",\"created_by\":1,\"created_at\":\"2026-06-10 09:17:32\",\"assigned_by\":1,\"assigned_at\":\"2026-06-10 09:17:32\"}', '2026-06-10 09:17:32', '2026-06-10 10:17:32'),
('11', '7', '5', 'status', 'Draft', 'In Progress', '2026-06-10 09:18:09', '2026-06-10 10:18:09'),
('12', '8', '1', 'created', NULL, '{\"task_number\":\"TASK-00008\",\"title\":\"head\",\"task_type\":\"File Attached\",\"description\":\"test\",\"priority\":\"High\",\"status\":\"Draft\",\"department_id\":3,\"category_id\":2,\"assigned_to\":5,\"estimated_hours\":1,\"due_date\":\"2026-06-11\",\"created_by\":1,\"created_at\":\"2026-06-10 09:34:59\",\"assigned_by\":1,\"assigned_at\":\"2026-06-10 09:34:59\"}', '2026-06-10 09:34:59', '2026-06-10 10:34:59');


DROP TABLE IF EXISTS `task_mentions`;
CREATE TABLE `task_mentions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `comment_id` int(10) unsigned DEFAULT NULL,
  `mentioned_user_id` int(10) unsigned NOT NULL,
  `mentioned_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tm_task_id` (`task_id`),
  KEY `idx_tm_mentioned_user_id` (`mentioned_user_id`),
  CONSTRAINT `fk_tm_mentioned_user_id` FOREIGN KEY (`mentioned_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tm_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `task_reminders`;
CREATE TABLE `task_reminders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `remind_at` datetime NOT NULL,
  `reminder_type` enum('due_date','custom') DEFAULT 'due_date',
  `sent` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tr_task_id` (`task_id`),
  KEY `idx_tr_user_id` (`user_id`),
  KEY `idx_tr_remind_at` (`remind_at`),
  CONSTRAINT `fk_tr_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tr_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `task_tags`;
CREATE TABLE `task_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `tag` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ttag_task_id` (`task_id`),
  KEY `idx_ttag_tag` (`tag`),
  CONSTRAINT `fk_ttag_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `task_templates`;
CREATE TABLE `task_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `priority` enum('Low','Medium','High','Critical') DEFAULT 'Medium',
  `estimated_hours` decimal(8,2) DEFAULT NULL,
  `template_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`template_data`)),
  `is_public` tinyint(1) DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tt_category_id` (`category_id`),
  KEY `idx_tt_department_id` (`department_id`),
  KEY `idx_tt_created_by` (`created_by`),
  CONSTRAINT `fk_tt_category_id` FOREIGN KEY (`category_id`) REFERENCES `task_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tt_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tt_department_id` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `task_watchers`;
CREATE TABLE `task_watchers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tw_task_user` (`task_id`,`user_id`),
  KEY `idx_tw_task_id` (`task_id`),
  KEY `idx_tw_user_id` (`user_id`),
  CONSTRAINT `fk_tw_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tw_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_number` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `task_type` enum('Normal','File Attached','Initiation') DEFAULT 'Normal',
  `description` text DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `priority` enum('Low','Medium','High','Critical') DEFAULT 'Medium',
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `assigned_by` int(10) unsigned DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT NULL,
  `status` enum('Draft','Pending','In Progress','Under Review','Completed','Rejected','Cancelled','Overdue') DEFAULT 'Draft',
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `estimated_completion_date` date DEFAULT NULL,
  `estimated_hours` decimal(8,2) DEFAULT NULL,
  `actual_hours` decimal(8,2) DEFAULT 0.00,
  `progress_percentage` int(11) DEFAULT 0,
  `attachment` varchar(255) DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `completed_by` int(10) unsigned DEFAULT NULL,
  `archived` tinyint(1) DEFAULT 0,
  `recurring_type` enum('none','daily','weekly','monthly','yearly') DEFAULT 'none',
  `recurring_interval` int(10) unsigned DEFAULT 1,
  `recurring_end_date` date DEFAULT NULL,
  `template_id` int(10) unsigned DEFAULT NULL,
  `escalated` tinyint(1) DEFAULT 0,
  `disputed` tinyint(1) DEFAULT 0,
  `rejection_reason` text DEFAULT NULL,
  `completed_notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tasks_task_number` (`task_number`),
  KEY `idx_tasks_category_id` (`category_id`),
  KEY `idx_tasks_department_id` (`department_id`),
  KEY `idx_tasks_assigned_to` (`assigned_to`),
  KEY `idx_tasks_assigned_by` (`assigned_by`),
  KEY `idx_tasks_status` (`status`),
  KEY `idx_tasks_priority` (`priority`),
  KEY `idx_tasks_due_date` (`due_date`),
  KEY `idx_tasks_created_by` (`created_by`),
  KEY `idx_tasks_recurring_type` (`recurring_type`),
  KEY `idx_tasks_escalated` (`escalated`),
  KEY `idx_tasks_disputed` (`disputed`),
  CONSTRAINT `fk_tasks_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tasks_assigned_to` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tasks_category_id` FOREIGN KEY (`category_id`) REFERENCES `task_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tasks_department_id` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tasks` (`id`, `task_number`, `title`, `task_type`, `description`, `category_id`, `department_id`, `priority`, `assigned_to`, `assigned_by`, `assigned_at`, `status`, `start_date`, `due_date`, `estimated_completion_date`, `estimated_hours`, `actual_hours`, `progress_percentage`, `attachment`, `completed_at`, `completed_by`, `archived`, `recurring_type`, `recurring_interval`, `recurring_end_date`, `template_id`, `escalated`, `disputed`, `rejection_reason`, `completed_notes`, `created_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1', 'TASK-00001', 'User Dashboard Redesign', 'Normal', 'Redesign the user dashboard with new charts and widgets', '2', '2', 'High', '2', '1', NULL, 'In Progress', '2026-06-01', '2026-06-20', NULL, '40.00', '0.00', '60', NULL, NULL, NULL, '0', 'none', '1', NULL, NULL, '0', '0', NULL, NULL, NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('2', 'TASK-00002', 'API Integration Module', 'Normal', 'Build REST API integration for third-party services', '1', '15', 'Critical', '3', '1', NULL, '', '2026-06-05', '2026-06-25', NULL, '60.00', '0.00', '0', NULL, NULL, NULL, '0', 'none', '1', NULL, NULL, '0', '0', NULL, NULL, NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('3', 'TASK-00003', 'Database Optimization', 'Normal', 'Optimize slow queries and add missing indexes', '3', '16', 'Medium', '4', '1', NULL, 'Completed', '2026-05-20', '2026-06-10', NULL, '25.00', '0.00', '100', NULL, '2026-06-09 12:31:46', NULL, '0', 'none', '1', NULL, NULL, '0', '0', NULL, NULL, NULL, '2026-06-09 12:31:36', '2026-06-09 12:31:46', NULL),
('4', 'TASK-00004', 'Test', 'Normal', 'dddd', '2', '3', 'Medium', '5', '1', '2026-06-09 12:40:09', 'Completed', NULL, '2026-06-10', NULL, '1.00', NULL, '0', NULL, '2026-06-09 16:03:48', NULL, '0', 'none', '1', NULL, NULL, '0', '0', NULL, NULL, '1', '2026-06-09 12:40:09', '2026-06-09 17:03:48', NULL),
('5', 'TASK-00005', 'Test2', 'File Attached', 'fast', '2', '3', 'High', '5', '1', '2026-06-10 08:56:24', 'Draft', NULL, '2026-06-11', NULL, '5.00', '0.00', '0', NULL, NULL, NULL, '0', 'none', '1', NULL, NULL, '0', '0', NULL, NULL, '1', '2026-06-10 08:56:24', '2026-06-10 09:56:24', NULL),
('6', 'TASK-00006', 'Test3', 'File Attached', 'sure', '2', '3', 'Low', '5', '1', '2026-06-10 09:04:21', 'Draft', NULL, '2026-06-11', NULL, '1.00', '0.00', '0', NULL, NULL, NULL, '0', 'none', '1', NULL, NULL, '0', '0', NULL, NULL, '1', '2026-06-10 09:04:21', '2026-06-10 10:04:21', NULL),
('7', 'TASK-00007', 'test', 'Normal', 'tttt', '2', '3', 'Low', '5', '1', '2026-06-10 09:17:32', 'In Progress', NULL, '2026-06-11', NULL, '1.00', '0.00', '0', NULL, NULL, NULL, '0', 'none', '1', NULL, NULL, '0', '0', NULL, NULL, '1', '2026-06-10 09:17:32', '2026-06-10 10:18:09', NULL),
('8', 'TASK-00008', 'head', 'File Attached', 'test', '2', '3', 'High', '5', '1', '2026-06-10 09:34:59', 'Draft', NULL, '2026-06-11', NULL, '1.00', '0.00', '0', NULL, NULL, NULL, '0', 'none', '1', NULL, NULL, '0', '0', NULL, NULL, '1', '2026-06-10 09:34:59', '2026-06-10 10:34:59', NULL);


DROP TABLE IF EXISTS `user_files`;
CREATE TABLE `user_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned DEFAULT NULL,
  `original_name` varchar(255) NOT NULL,
  `stored_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `folder` varchar(100) DEFAULT '/',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_uf_user_id` (`user_id`),
  KEY `idx_uf_task_id` (`task_id`),
  KEY `idx_uf_folder` (`folder`),
  CONSTRAINT `fk_uf_task_id` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_uf_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_files` (`id`, `user_id`, `task_id`, `original_name`, `stored_name`, `file_path`, `mime_type`, `file_size`, `folder`, `created_at`, `updated_at`) VALUES
('1', '5', NULL, 'Enterprise_Task_Management_System_Prompt.pdf', 'file_5_1781011782_18f8c3896cb6722b.pdf', 'public/storage/uploads/user-files/file_5_1781011782_18f8c3896cb6722b.pdf', 'application/pdf', '99726', '/', '2026-06-09 15:29:42', '2026-06-09 16:29:42');


DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `user_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  `granted` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`,`permission_id`),
  KEY `idx_user_permissions_permission_id` (`permission_id`),
  CONSTRAINT `fk_user_permissions_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_permissions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `user_preferences`;
CREATE TABLE `user_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`preferences`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_preferences_user_id` (`user_id`),
  CONSTRAINT `fk_user_preferences_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_preferences` (`id`, `user_id`, `preferences`, `created_at`, `updated_at`) VALUES
('1', '1', '{\"email_notifications\":1,\"browser_notifications\":0,\"task_assigned\":0,\"task_completed\":0,\"task_overdue\":0,\"mention_notifications\":0}', '2026-06-09 13:23:20', '2026-06-09 13:23:20'),
('2', '5', '{\"email_notifications\":1,\"browser_notifications\":0,\"task_assigned\":0,\"task_completed\":0,\"task_overdue\":0,\"mention_notifications\":0}', '2026-06-09 13:26:15', '2026-06-09 13:26:15');


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `status` enum('Active','Inactive','Suspended','Locked') DEFAULT 'Active',
  `avatar` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `failed_attempts` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_employee_id` (`employee_id`),
  UNIQUE KEY `uk_users_username` (`username`),
  UNIQUE KEY `uk_users_email` (`email`),
  KEY `idx_users_department_id` (`department_id`),
  KEY `idx_users_role_id` (`role_id`),
  KEY `idx_users_status` (`status`),
  CONSTRAINT `fk_users_department_id` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_users_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `employee_id`, `first_name`, `last_name`, `username`, `email`, `mobile`, `department_id`, `role_id`, `status`, `avatar`, `password`, `failed_attempts`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1', 'ADMIN-001', 'Osman', 'Sharif Ali', 'admin', 'ozmanarab12@icloud.com', '0618362929', '1', '1', 'Active', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0', '2026-06-09 12:15:38', '2026-06-09 12:53:42', NULL),
('2', 'EMP-0001', 'John', 'Doe', 'john', 'john@taskms.com', '555-0101', '2', '4', 'Active', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('3', 'EMP-0002', 'Jane', 'Smith', 'jane', 'jane@taskms.com', '555-0102', '15', '2', 'Active', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('4', 'EMP-0003', 'Bob', 'Wilson', 'bob', 'bob@taskms.com', '555-0103', '16', '3', 'Active', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0', '2026-06-09 12:31:36', '2026-06-09 12:31:36', NULL),
('5', 'EMP-0004', 'Abdinasir', 'Salad Omar', 'JBH00177', 'Binnaasir.mog@gmail.com', '0619068203', '2', '4', 'Active', NULL, '$2y$10$Ffm/CoP7LN5o7P392AryaesMjAX2qMgcsq3P9vwjjmvn1RJ8UqFaG', '0', '2026-06-09 12:08:38', '2026-06-10 09:54:03', NULL);

SET FOREIGN_KEY_CHECKS = 1;
